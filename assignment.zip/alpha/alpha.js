function alphabet_order(str)  
  {  
return str.split('').sort().join('');  
  }  
document.write(alphabet_order("mahesh"));