function addtext()
          {
             var fname = document.myform.Fullname.value;
             var stadd = document.myform.StreetAddress.value;
             var town = document.myform.Town.value;
             var city = document.myform.City.value;
             var country = document.myform.Country.value;
             var zipcode = document.myform.Zipcode.value;
             var tele = document.myform.Telephone.value;
             var email = document.myform.email.value;
     var it1 = document.myform.Item1.value;
     var qty1 = document.myform.Qty1.value;
     var it2 = document.myform.Item2.value;
     var qty2 = document.myform.Qty2.value;
     var it3 = document.myform.Item3.value;
     var qty3 = document.myform.Qty3.value;
     var it4 = document.myform.Item4.value;
     var qty4 = document.myform.Qty4.value;
     var it5 = document.myform.Item5.value;
     var qty5 = document.myform.Qty5.value;
     var it6 = document.myform.Item6.value;
     var qty6 = document.myform.Qty6.value;
     var it7 = document.myform.Item7.value;
     var qty7 = document.myform.Qty7.value;
     var it8 = document.myform.Item8.value;
     var qty8 = document.myform.Qty8.value;
     var it9 = document.myform.Item9.value;
     var qty9 = document.myform.Qty9.value;
     var it10 = document.myform.Item10.value;
     var qty10 = document.myform.Qty10.value;
    
             document.writeln("Thank you! You have just entered the following:");
             document.writeln("<pre>");
             document.writeln("Full name        : " + fname);
             document.writeln("Street Address   : " + stadd)
             document.writeln("Town             : " + town);
             document.writeln("City             : " + city)
             document.writeln("Country          : " + country);
             document.writeln("Zip Code         : " + zipcode)
             document.writeln("Telephone        : " + tele);
             document.writeln("Email Address    : " + email);
    document.writeln("Item 1           : " + it1+ "  and  " +"Qty  :" + qty1);
    document.writeln("Item 2           : " + it2+ "  and  " +"Qty  :" + qty2);
    document.writeln("Item 3           : " + it3+ "  and  " +"Qty  :" + qty3);
    document.writeln("Item 4           : " + it4+ "  and  " +"Qty  :" + qty4);
    document.writeln("Item 5           : " + it5+ "  and  " +"Qty  :" + qty5);
    document.writeln("Item 6           : " + it6+ "  and  " +"Qty  :" + qty6);
    document.writeln("Item 7           : " + it7+ "  and  " +"Qty  :" + qty7);
    document.writeln("Item 8           : " + it8+ "  and  " +"Qty  :" + qty8);
    document.writeln("Item 9           : " + it9+ "  and  " +"Qty  :" + qty9);
    document.writeln("Item 10          : " + it10+"  and  "+"Qty  :" + qty10);
    
    
    
          }
